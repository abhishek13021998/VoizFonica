package com.voizfonica.project;

import org.springframework.data.jpa.repository.JpaRepository;

public interface NewConnectionRepository  extends JpaRepository<NewConnection, Integer> {
	

}
