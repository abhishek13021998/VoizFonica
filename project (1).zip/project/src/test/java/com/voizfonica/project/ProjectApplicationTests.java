package com.voizfonica.project;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectApplicationTests {
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	NewConnectionService newConnectionService;
	@Autowired
	PlansRepository plansRepository;
	
	@Autowired
	PlansService planService;
	
	@Autowired
	UserService userService;
	@Autowired
	TicketsService ticketsService;

	/*@Test
	void testForFetchById() {
		User user=userRepository.findByemailid("navya@gmail.com");
		String expected ="navya@gmail.com";
		String actual=user.getEmailid();
		assertEquals(expected,actual);
	}
	@Test
	void testSaveNewConnectionRequest() {
		NewConnection connection=new NewConnection("a","b","c","d","e");
		NewConnection returned=newConnectionService.saveNewConnectionRequest(connection);
		String expected ="a";
		String actual=returned.getEmailid();
		assertEquals(expected,actual);
	}
	@Test
	void testFetchByPlanType() {
		List<Plans> plans=plansRepository.findByplantype("prepaid");
	  assertTrue(!plans.isEmpty());
	}
	
	@Test
	void testSavePlan(){
		Plans plan = new Plans(11,"Data","postpaid","30 days","450/-");
		String actual=planService.save(plan).getPlanvalidity();
		String expected = "30 days";
		assertEquals(expected,actual);		
	}
	

	
	@Test
	void testSaveUSer() {
		User user=new User(1244,"abcd@gmail.com","ABCD","abcdef","9578987898");
		String actual=userService.saveUser(user).getUsername();
		String expected= "ABCD";
		assertEquals(expected,actual);
	}*/
	@Test 
	void testGetcustomerTickets() {
		List<Tickets> tickets=ticketsService.getTicket(26);
		System.out.println(tickets.size());
		assertTrue(!tickets.isEmpty());
	}

}
